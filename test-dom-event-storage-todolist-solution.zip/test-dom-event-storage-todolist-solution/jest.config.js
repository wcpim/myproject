module.exports = {
  testEnvironment: 'jsdom'
}
